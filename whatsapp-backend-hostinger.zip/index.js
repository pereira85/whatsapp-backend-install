
const express = require('express');
const { Client } = require('whatsapp-web.js');
const qrcode = require('qrcode');
const socketIO = require('socket.io');
const http = require('http');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIO(server, { cors: { origin: '*' } });

const client = new Client();

client.on('qr', async (qr) => {
  const qrImage = await qrcode.toDataURL(qr);
  io.emit('qr', qrImage);
});

client.on('ready', () => {
  console.log('✅ WhatsApp conectado!');
  io.emit('ready');
});

client.on('authenticated', () => {
  console.log('🔐 Autenticado');
});

client.initialize();

app.use(express.static(path.join(__dirname, 'public')));

io.on('connection', (socket) => {
  console.log('🟢 Novo cliente conectado via WebSocket');
});

server.listen(3000, () => {
  console.log('🚀 Servidor rodando em http://localhost:3000');
});
